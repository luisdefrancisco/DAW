// Luis Martín de Francisco Blanco
// DAW: ENTORNOS DE DESARROLLO
// TAREA 2 UD02 Instalación y uso de entornos de desarrollo

public class Main {
    public static void main(String[] args) {

        System.out.println("Hola Mundo me llamo Luis!");

    }
}