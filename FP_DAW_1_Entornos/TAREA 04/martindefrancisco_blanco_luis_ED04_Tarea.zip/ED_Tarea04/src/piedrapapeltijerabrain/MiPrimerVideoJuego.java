package piedrapapeltijerabrain;

import java.util.Scanner;

/**
 *
 * @author Alfredo
 * @version 1.0 20/02/24
 * Juego piedra papel o tijera que utiliza un bot como oponente al jugador
 * El programa indica al jugador en cada jugada si debe perder o ganar
 * teniendo en cuenta la jugada del bot por adelantado.
 * El jugador jugará despues de conocer la jugada del bot.
 * La finalidad del juego es cronometrar 5 jugadas intentando 
 * acertar cada jugada
 * Al jugador se le penaliza con 5 segundos por cada fallo
 * Gana el que menos tiempo necesite incluyendo las penalizaciones
 * 
 */
public class MiPrimerVideoJuego {

    /**
     * @param args the command line arguments
     * Clase principal que gestiona el flujo del juego
     * Calcula el tiempo en que se han jugado cinco partidas
     * Utiliza tres metodos para presentar en ascii las jugadas
     * @see tijera() 
     * @see papel() 
     * @see piedra()
     * Variable proposito -> Utiliza un método random de Math para definir 
     * cada jugada aleatoriamente. Es decir, si debe ganarse o perderse
     * Variable j -> Define aleatoriamente la jugada del bot
     * Mediante un Do-While evita que el jugador introduzca la misma jugada que 
     * el bot.
     * Se desarrolla mediante distintos if, las diferentes combinaciones de 
     * jugadas entre bot y jugador
     * Contabiliza los fallos y aciertos, y mediante la diferencia entre inicio
     * y fin calculados bajo el metodo currentTimeMillis se calcula el tiempo
     * 
     * 
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int chiquipuntos = 0;
        Scanner sc = new Scanner(System.in);
        String opcionJugador = "";
        String opcionBot = "";
        int exitoEnProposito = 1;
        long inicio = System.currentTimeMillis();
        for (int i = 0; i < 5; i++) {
            int proposito = (int) Math.floor(Math.random() * 2 + 1);
            if (proposito == 1) {
                System.out.println("\n\tIntenta ganar");
            }
            if (proposito == 2) {
                System.out.println("\n\tIntenta perder");
            }
            int j = (int) Math.floor(Math.random() * 3 + 1);

            if (j == 1) {
                opcionBot = "tijera";
                System.out.println(opcionBot);
                tijera();

            }
            if (j == 2) {
                opcionBot = "papel";
                System.out.println(opcionBot);
                papel();
            }
            if (j == 3) {
                opcionBot = "piedra";
                System.out.println(opcionBot);
                piedra();

            }
            do {
                System.out.println("Introduce tu jugada");
                opcionJugador = sc.nextLine();
                if (opcionBot.equals(opcionJugador)) {
                    System.out.println("No tiene sentido que intentes empatar");
                }

            } while (opcionBot == opcionJugador);
            if (opcionJugador.equals("tijera") && (opcionBot.equals("papel"))) {
                exitoEnProposito = 1;

            }

            if (opcionJugador.equals("papel") && (opcionBot.equals("tijera"))) {
                exitoEnProposito = -1;

            }

            if (opcionJugador.equals("tijera") && (opcionBot.equals("piedra"))) {
                exitoEnProposito = -1;

            }
            if (opcionJugador.equals("piedra") && (opcionBot.equals("tijera"))) {
                exitoEnProposito = 1;
            }

            if (opcionJugador.equals("piedra") && (opcionBot.equals("papel"))) {
                exitoEnProposito = -1;
            }
            if (opcionJugador.equals("papel") && (opcionBot.equals("piedra"))) {
                exitoEnProposito = 1;
            }
            if (proposito == 2) {
                exitoEnProposito *= -1;

            }
            if (exitoEnProposito == 1) {
                chiquipuntos++;
            }
        }
        long fin = System.currentTimeMillis();

        double tiempo = (double) ((fin - inicio) / 1000);
        System.out.println("Has realizado el ejercicio en " + tiempo + " segundos");
        int nFallos = 5 - chiquipuntos;
        System.out.println("Penalización: " + nFallos + " x 5s  = " + nFallos * 5);
        double tiempoFinal = tiempo + nFallos * 5;
        System.out.println("Tu tiempo final es de " + tiempoFinal + " segundos");
        System.out.println("¡Vuelve a jugar con nosotros!");
        System.out.println("¡Es muy ivertido!");
    }

    /**
     * @author Alfredo
     * @version 1.0
     * Impresión por pantalla de la figura de TIJERA mediante ASCII
     */
    public static void tijera() {
        System.out.println("'''\n"
                + "    _______\n"
                + "---'   ____)____\n"
                + "          ______)\n"
                + "       __________)\n"
                + "      (____)\n"
                + "---.__(___)\n"
                + "'''");
    }
    
    /**
     * @author Alfredo
     * @version 1.0
     * Impresión por pantalla de la figura de PAPEL mediante ASCII
     */
    public static void papel() {
        System.out.println("'''\n"
                + "     _______\n"
                + "---'    ____)____\n"
                + "           ______)\n"
                + "          _______)\n"
                + "         _______)\n"
                + "---.__________)");
    }

    /**
     * @author Alfredo
     * @version 1.0
     * Impresión por pantalla de la figura de PIEDRA mediante ASCII
     */
    public static void piedra() {
        System.out.println("'''\n"
                + "    _______\n"
                + "---'   ____)\n"
                + "      (_____)\n"
                + "      (_____)\n"
                + "      (____)\n"
                + "---.__(___)\n"
                + "'''");
    }

}
