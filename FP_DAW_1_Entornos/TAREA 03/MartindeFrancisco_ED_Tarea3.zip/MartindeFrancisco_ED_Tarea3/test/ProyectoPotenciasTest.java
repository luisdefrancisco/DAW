/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Ignore;

/**
 *
 * @author Luis Martin de Francisco
 */
public class ProyectoPotenciasTest {
    
    public ProyectoPotenciasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class ProyectoPotencias.
     */
    @Ignore
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ProyectoPotencias.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of potenciaIterativa method, of class ProyectoPotencias.
     */
    @Ignore
    @Test
    public void testPotenciaIterativa() {
        System.out.println("potenciaIterativa");
        int x = 2;
        int y = 3;
        double expResult = 7.0;
        double result = ProyectoPotencias.potenciaIterativa(x, y);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of potenciaRecursiva method, of class ProyectoPotencias.
     */
    @Test
    public void testPotenciaRecursiva() {
        System.out.println("potenciaRecursiva");
        int x = 2;
        int y = 3;
        double expResult = -8.0;
        double result = ProyectoPotencias.potenciaRecursiva(x, y);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
