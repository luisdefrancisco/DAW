
import java.util.Scanner;

/**
 *
 * @author Luis Martin de Francisco
 */
public class ProyectoPrimo {

    public static void main(String[] args) {
        // TODO code application logic here
        // Un numero primo es aquel que sea SOLO divisible por si mismo y por la unidad
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un numero ");
        int numero = sc.nextInt();
        String resultado=(primo(numero))?"El numero es primo":"El numero no es primo";
        System.out.println(resultado);
    }
    public static boolean primo(int num){
        boolean cierto=true;
        for(int i=2; i<num;i++){
            if(num%i==0){
                cierto=false;
            } //Cerramos if
        } //Cerramos for
        return cierto;
    } 
}
