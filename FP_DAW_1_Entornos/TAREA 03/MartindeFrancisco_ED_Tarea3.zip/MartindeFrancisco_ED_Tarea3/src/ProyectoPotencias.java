/**
 *
 * @author Luis Martin de Francisco
 */
import java.util.Scanner;

public class ProyectoPotencias {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la base ");
        int base = sc.nextInt();
        System.out.println("Introduzca el explonente ");
        int exponente = sc.nextInt();
        System.out.println("El valor de la potencia "+base+" ^ "+exponente+" = "+Math.pow(base,exponente));
        System.out.println("El valor de la potencia "+base+" ^ "+exponente+" = "+potenciaIterativa(base,exponente));
        System.out.println("El valor de la potencia "+base+" ^ "+exponente+" = "+potenciaRecursiva(base,exponente));            
    }
    public static double potenciaIterativa(int x, int y){
        int resultado = 1;
        for (int i=0; i<y; i++){
            resultado=resultado*x;
        }
        return resultado;
    }
    
    public static double potenciaRecursiva(int x, int y){
        if (y==0){
            return 1;
        } else{
            return x*potenciaRecursiva(x, y-1);
        }
    }
}
